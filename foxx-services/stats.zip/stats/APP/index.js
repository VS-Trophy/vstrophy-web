'use strict';
const createRouter = require('@arangodb/foxx/router');
const router = createRouter();
const joi = require('joi');
const db = require('@arangodb').db;
const queries = require('queries/queries.js')
const aql = require('@arangodb').aql;
const errors = require('@arangodb').errors;
const teamCollection = db._collection('VSTrophyTeams');
const DOC_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;



module.context.use(router);

// continued
router.get('/team/:key', function (req, res) {
  try {
  //  const team = teamCollection.document(req.pathParams.key);
    res.send(queries.topMatch)
  } catch (e) {
    if (!e.isArangoError || e.errorNum !== DOC_NOT_FOUND) {
      throw e;
    }
    res.throw(404, 'The entry does not exist', e);
  }
})
.pathParam('key', joi.string().required(), 'NFL ID of the team.')
.response(['application/json'], 'A personalized greeting.')
.summary('Personalized greeting')
.description('Prints a personalized greeting.');